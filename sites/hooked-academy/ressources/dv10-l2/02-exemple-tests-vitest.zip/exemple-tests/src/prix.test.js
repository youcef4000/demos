import { describe, it, expect } from 'vitest';
import { total } from './prix.js';

describe('total', () => {
  it('additionne le service et les options', () => {
    expect(total(2500, [500, 300])).toBe(3300);
  });
  it('applique la remise', () => {
    expect(total(3000, [], 10)).toBe(2700);
  });
  it('refuse une remise trop forte', () => {
    expect(() => total(3000, [], 80)).toThrow('Remise invalide');
  });
});
