// Total d'une réservation : prix du service + options, remise en pourcentage (0 à 50).
export function total(prix, options = [], remise = 0) {
  if (!Number.isFinite(prix) || prix < 0) throw new Error('Prix invalide');
  if (remise < 0 || remise > 50) throw new Error('Remise invalide');
  const brut = prix + options.reduce((s, o) => s + o, 0);
  return Math.round(brut * (1 - remise / 100));
}
