import http from 'node:http';

const port = process.env.PORT || 3000;

http
  .createServer((req, res) => {
    if (req.url === '/api/sante') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ ok: true }));
    }
    res.writeHead(404);
    res.end();
  })
  .listen(port, () => console.log(`Serveur sur le port ${port}`));
